BARRIO FIESTA BDAY — FIREBASE HOSTING (NO LOGIN)

PROJECT: barrio-fiesta-bday--jex

This website allows PUBLIC editing of event details, food, suppliers, program, games and prices. Anybody on the internet who discovers the database paths can modify or delete entries. Avoid sensitive personal information and keep backups.

DEPLOY WITH FIREBASE CLI (computer or browser-based terminal with Node.js):
1. Extract this ZIP. Open terminal inside the extracted folder.
2. Run: npm install -g firebase-tools
3. Run: firebase login
4. Run: firebase use barrio-fiesta-bday--jex
5. Run: firebase deploy --only hosting,firestore:rules
6. Open the Hosting URL shown by Firebase and test adding an item on two devices.

IMPORTANT: Do not publish the public database rules until the website is deployed and you accept the public editing risk. Do not upload ZIP directly into Firebase Console: Firebase Hosting deployment requires CLI or another supported deploy workflow.

The supplied app.js Firebase apiKey was corrected to match the config provided by the project owner. Firebase API keys are client-side identifiers; they do not secure Firestore data.
